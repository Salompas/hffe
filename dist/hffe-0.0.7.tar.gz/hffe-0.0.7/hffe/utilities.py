import time


def timeFunction(func):
    """Times one execution of function.

    Args:
        func (function): Function that takes no arguments.

    Returns:
        wrapper (function): Function that executes func and prints the time
                it took to finish running (in seconds).
    """
    def wrapper():
        start = time.time()
        func()
        elapsed = time.time() - start
        print(f'Elapsed time: {elapsed:.2f} seconds.')
    return wrapper
